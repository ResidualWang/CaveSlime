﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class StartScene : MonoBehaviour {

	public Rigidbody2D a;
	public Rigidbody2D b;
	public Transform pos;
	public bool isstart;
	

	void Start () {
		a.isKinematic = true;
		b.isKinematic = true;
	}
	
	void Update () {
		if(isstart)
		{
			a.transform.Translate(Vector3.right * 3f * Time.deltaTime);
			b.transform.Translate(Vector3.right * 3f * Time.deltaTime);
			b.transform.localEulerAngles = new Vector3(0,0,0);
		}
	}

	public void startgame()
	{
		StartCoroutine("StartGame");
		Debug.Log("a");
	}

	public void QuitGame()
	{
		Application.Quit();
	}

	IEnumerator StartGame()
	{
		a.isKinematic = false;
		b.isKinematic = false;
		yield return new WaitForSeconds(1.5f);
		isstart = true;
		yield return new WaitForSeconds(2f);
		SceneManager.LoadScene("PlayScene");
	}
}
