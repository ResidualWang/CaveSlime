﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraChange : MonoBehaviour {

	public GameObject prefabs;
	public CameraFollow cameraFollow;
    public PlayerMove playerMove;
	public bool ishaveother;
	public Count count;
	public OtherDel otherDel;


	void Start () {
		otherDel = Camera.main.GetComponent<OtherDel>();
	}
	
	void Update () {

		if(Input.GetKeyDown(KeyCode.L) && ishaveother == false)
		{
			CreatNew();
		}

	}

	public void CreatNew()
	{
		GameObject a = Instantiate(prefabs,new Vector3(transform.localPosition.x + 3f,transform.localPosition.y,0),Quaternion.identity);
		cameraFollow.changeplayer(a.transform);
		ishaveother = true;
		playerMove.ishaveother = true;
		count.deadTotal += 1;
		otherDel.others.Add(a);
	}
}
