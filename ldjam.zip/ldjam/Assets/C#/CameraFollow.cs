﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour {

    public Transform target;
    private Vector3 offset;

	void Awake()
	{
		target = GameObject.Find("player").transform;
	}
   
   void Start()
    {
      offset = target.position - this.transform.position;
    }

   void Update()
    {
        this.transform.position = target.position - offset;
    }

	public void changeplayer(Transform player)
	{
		transform.position = new Vector3(player.position.x,player.position.y,-10);
		target = player;
	}
}
