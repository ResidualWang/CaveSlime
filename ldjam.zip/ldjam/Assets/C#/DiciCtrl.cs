﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DiciCtrl : MonoBehaviour {

	public OtherDel otherDel;


	void Start () {
		otherDel = Camera.main.GetComponent<OtherDel>();
	}
	
	void Update () {
		
	}

	void OnTriggerEnter2D(Collider2D collider) {
		if(collider.tag == "Other")
		{
			collider.gameObject.GetComponent<OtherCtrl>().Dead(true);
		}
		if(collider.tag == "Player")
		{
			collider.gameObject.GetComponent<CheckPoint>().BackToPoint();
			otherDel.Delete();
		}
    }
}
