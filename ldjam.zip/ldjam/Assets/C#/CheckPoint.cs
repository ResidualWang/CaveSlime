﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckPoint : MonoBehaviour {

	public Transform pos;

	public GameObject player;

	void Awake() {
	}
	
	void Update () {
		
	}

	public void BackToPoint()
	{
		player.transform.position = Vector2.MoveTowards(player.transform.position,pos.position,10000f);
	}
}
