﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KnifeCtrl : MonoBehaviour {

	public bool a;
	public bool b;
	public bool isend;
	public float speed;
	public OtherDel otherDel;

	void Awake () {
		InvokeRepeating("Change",0f,speed);
	}

	void Start()
	{
		otherDel = Camera.main.GetComponent<OtherDel>();
	}
	
	void Update () {

		transform.Rotate(new Vector3(0,0,5));

		if(a&&isend)
		{
			transform.Translate(Vector2.right * 15f * Time.deltaTime,Space.World);
		}
		if(a&&isend == false)
		{
			transform.Translate(Vector2.left * 15f * Time.deltaTime,Space.World);
		}
		if(b&&isend)
		{
			transform.Translate(Vector2.up * 15f * Time.deltaTime,Space.World);
		}
		if(b&&isend == false)
		{
			transform.Translate(Vector2.down * 15f * Time.deltaTime,Space.World);
		}

	}

	public void Change()
	{
		if(isend == false){isend = true;}else{isend = false;}
	}

	void OnTriggerEnter2D(Collider2D collider) {
		if(collider.tag == "Other")
		{
			collider.gameObject.GetComponent<OtherCtrl>().Dead(true);
		}
		if(collider.tag == "Player")
		{
			collider.gameObject.GetComponent<CheckPoint>().BackToPoint();
			otherDel.Delete();
		}
    }
}
