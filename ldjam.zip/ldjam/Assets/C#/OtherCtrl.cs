﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OtherCtrl : MonoBehaviour {

	public PlayerMove playerMove;
	public Transform playertrans;
	public GameObject player;
	public CameraFollow cameraFollow;
	public CameraChange cameraChange;
	public Rigidbody2D rigid;
	public bool jump;
	public bool jumptwo;
	public bool ishaveother;
	Vector3 nowposi;

	public bool isdead;
	public AudioSource jumpAudio;


	void Start () {
		player = GameObject.Find("player");
		playerMove = player.GetComponent<PlayerMove>();
		playertrans = player.transform;
		cameraFollow = Camera.main.GetComponent<CameraFollow>();
		cameraChange = player.GetComponent<CameraChange>();
		rigid = gameObject.GetComponent<Rigidbody2D>();
		jumpAudio = gameObject.GetComponent<AudioSource>();
	}
	
	void Update () {
		if(Input.GetKey(KeyCode.J))
		{
			Dead(false);
		}


		transform.localEulerAngles = new Vector3(transform.localEulerAngles.x,transform.localEulerAngles.y,0);

		if(isdead == true)
		return;

            if(Input.GetKey(KeyCode.A))
		    {
			    transform.Translate(Vector2.left * 5f * Time.deltaTime,Space.World);
			    transform.localEulerAngles = new Vector2(0,180);
		    }
		    if(Input.GetKey(KeyCode.D))
		    {
			    transform.Translate(Vector2.right * 5f * Time.deltaTime,Space.World);
			    transform.localEulerAngles = new Vector2(0,0);
		    }


		    if(jump == false)
		    {
			    if(Input.GetKeyDown(KeyCode.K))
			{
				rigid.AddForce(new Vector2(0, 400));
				jumpAudio.Play();
			}
			if(Input.GetKeyUp(KeyCode.K))
			{
			    jump = true;
			}
		    }

		    if(jump == true && jumptwo == false)
		    {
			    if(Input.GetKeyDown(KeyCode.K))
			    {
			        rigid.AddForce(new Vector2(0, 200));
			        jumptwo = true;
					jumpAudio.Play();
			    }
		    }

		

		
	}

	public void Dead(bool isdel)
	{
		cameraFollow.changeplayer(playertrans);
		playerMove.ishaveother = false;
		cameraChange.ishaveother = false;
		isdead = true;
		Destroy(rigid);
		nowposi = transform.localPosition;
		if(isdel == true)
		{
			Destroy(this.gameObject);
		}
	}

	public void OnCollisionEnter2D(Collision2D coll)
	{
		if(coll.gameObject.tag == "plane"||coll.gameObject.tag == "Player"||coll.gameObject.tag == "Other")
		{
			jump = false;
			jumptwo = false;
		}
	}
}
