﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OtherDel : MonoBehaviour {

	public List<GameObject> others = new List<GameObject>();

	void Start () {
		
	}
	
	void Update () {
		
	}

	public void Delete()
	{
		for (int i = 0; i < others.Count; i++)
		{
			Destroy(others[i]);
		}
	}

}
