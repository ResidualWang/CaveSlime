﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour {

	public Rigidbody2D rigid;
	public bool jump;
	public bool jumptwo;
	public bool ishaveother;
	Vector3 nowposi;
	public AudioSource jumpAudio;


	void Start () {
		rigid = gameObject.GetComponent<Rigidbody2D>();
		jumpAudio = gameObject.GetComponent<AudioSource>();
	}
	

	void Update () {

		if(ishaveother == false)
		{
			if(Input.GetKey(KeyCode.A))
		    {
			    transform.Translate(Vector2.left * 5f * Time.deltaTime,Space.World);
			    transform.localEulerAngles = new Vector2(0,180);
		    }
		    if(Input.GetKey(KeyCode.D))
		    {
			    transform.Translate(Vector2.right * 5f * Time.deltaTime,Space.World);
			    transform.localEulerAngles = new Vector2(0,0);
		    }

		    transform.localEulerAngles = new Vector3(transform.localEulerAngles.x,transform.localEulerAngles.y,0);

		    if(jump == false)
		    {
			    if(Input.GetKeyDown(KeyCode.K))
			    {
				    rigid.AddForce(new Vector2(0, 400));
					jumpAudio.Play();
			    }
			    if(Input.GetKeyUp(KeyCode.K))
			    {
			        jump = true;
			    }
		    }

		    if(jump == true && jumptwo == false)
		    {
			    if(Input.GetKeyDown(KeyCode.K))
			    {
			        rigid.AddForce(new Vector2(0, 200));
			        jumptwo = true;
					jumpAudio.Play();
			    }
		    }

			nowposi = new Vector3(transform.localPosition.x,transform.localPosition.y,transform.localPosition.z);
		}

		if(ishaveother == true)
		{
			transform.localPosition = new Vector3(nowposi.x,transform.localPosition.y,0);
		}

		

	}

	public void OnCollisionEnter2D(Collision2D coll)
	{
		if(coll.gameObject.tag == "plane"||coll.gameObject.tag == "Player"||coll.gameObject.tag == "Other" )
		{
			jump = false;
			jumptwo = false;
		}
	}




}
