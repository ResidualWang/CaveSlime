﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Count : MonoBehaviour {

	public Text DeadCount;
	public int deadTotal;

	void Start () {
		DeadCount = gameObject.GetComponent<Text>();
	}
	
	void Update () {
		DeadCount.text = "Lost companions："+ deadTotal;
	}
}
