﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZhongCtrl : MonoBehaviour {

	public GameObject zhong;
	bool ishavewater;

	Vector3 pos;

	void Start () {
		zhong = Resources.Load("Prefabs/water") as GameObject;
		ishavewater = false;
		pos = new Vector3(transform.localPosition.x,transform.localPosition.y - 2,0);
	}
	
	void Update () {
		if(ishavewater == false)
		{
			StartCoroutine(CreatWater());
		}
	}

	IEnumerator CreatWater()
	{
		ishavewater = true;
		Instantiate(zhong,pos,Quaternion.identity);
		yield return new WaitForSeconds(2f);
		ishavewater = false;
	}
}
