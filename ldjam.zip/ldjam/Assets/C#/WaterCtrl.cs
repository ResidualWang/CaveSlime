﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaterCtrl : MonoBehaviour {

	public OtherDel otherDel;

	void Start()
	{
		otherDel = Camera.main.GetComponent<OtherDel>();
	}

	void OnCollisionEnter2D(Collision2D coll)
	{
		if(coll.gameObject.tag == "Other")
		{
			coll.gameObject.GetComponent<OtherCtrl>().Dead(true);
		}

		if(coll.gameObject.tag == "Player")
		{
			coll.gameObject.GetComponent<CheckPoint>().BackToPoint();
			otherDel.Delete();
		}

		if(coll.gameObject.tag != "zhong")
		Destroy(this.gameObject);
	}
}
